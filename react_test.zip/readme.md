## API Testing Perch App
Laravel app with React frontend templating.
Uses 'axios' requests to api handles (defined in route/api.php) to yield data.

React components are located under resources/assets/js.
Instead of an index.html front page, we use 'welcome.blade.php' located under 
resources/views.

