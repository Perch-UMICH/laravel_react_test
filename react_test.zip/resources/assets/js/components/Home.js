/**
 * Created by aksha on 2/25/2018.
 */
import React from 'react'
import ReactDOM from 'react-dom';
import axios from 'axios'


class Home extends React.Component {

    render() {
        return[
            <h1>Home page</h1>,
        ]
    }
}

export default Home
