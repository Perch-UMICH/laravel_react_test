/**
 * Created by aksha on 2/25/2018.
 */
import React from 'react'
import { Link } from 'react-router-dom'


const Header = () => (
    <header>
        <nav>
            <ul>
                <li><Link to='/'>Home</Link></li>
                <li><Link to='/users'>Users</Link></li>
                <li><Link to='/students'>Students</Link></li>
                <li><Link to='/faculties'>Faculties</Link></li>
                <li><Link to='/labs'>Labs</Link></li>
                <li><Link to='/register'>Register</Link></li>
                <li><Link to='/login'>Login</Link></li>
                <li><a href={'login/google'}><img width={191} height={46} src={'../../images/btn_google_signin_dark_normal_web@2x.png'} /></a></li>
            </ul>
        </nav>
    </header>
);

export default Header
