<?php

namespace App\Http\Controllers;

use App\SchoolCourse;
use Illuminate\Http\Request;

class SchoolCourseController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $courses = SchoolCourse::all();
        return $this->outputJSON($courses,"School courses retrieved");
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\SchoolCourse  $schoolCourse
     * @return \Illuminate\Http\Response
     */
    public function show(SchoolCourse $schoolCourse)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\SchoolCourse  $schoolCourse
     * @return \Illuminate\Http\Response
     */
    public function edit(SchoolCourse $schoolCourse)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\SchoolCourse  $schoolCourse
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, SchoolCourse $schoolCourse)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\SchoolCourse  $schoolCourse
     * @return \Illuminate\Http\Response
     */
    public function destroy(SchoolCourse $schoolCourse)
    {
        //
    }
}
